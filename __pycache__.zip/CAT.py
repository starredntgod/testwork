from LineAPI.linepy import *
from LineAPI.akad import *
from LineAPI.akad.ttypes import *
import time,os,sys
from humanfriendly import format_timespan, format_size, format_number, format_length
import time, random, sys, json, codecs, threading, glob, re, string, os, requests, subprocess, six, ast, pytz, urllib, urllib.parse , pickle, null, tmp
from multiprocessing import Pool, Process
import multiprocessing as mp
from datetime import datetime
from time import sleep
from threading import Thread as Process
from tools import LiveJSON, FixJSON
from livejson import File as jopen
from Naked.toolshed.shell import execute_js
import traceback
from LineAPI.linepy.asynckick import AsyncKick

botStart = time.time()

settings = LiveJSON('settings.json')
FixJSON(settings,{
    "kickalljs": "kickalljs",
    "kickallpy": "kickallpy",
    "text": False,
    "autojoin": False,
    "blacklist":{},
    "wblacklist": False,
    "dblacklist": False,
    "setpicture": False,
    "autoblock": False,
    "notagkick": False,
    "autopost": False,
    "namekick":[],
    "protectkick":[],
    "protectqr":[],
    "protectjoin":[],
    "protectinvite":[],
    "protectcancel":[],
    "protectname":[],
    "protectnote":[],
    "protectcontact":[],
    })
 
dino = LINE("dangvock.pk956@gmail.com","963963da963",appName="ANDROIDLITE 2.17.0 Android OS 9;SECONDARY")

oepoll = OEPoll(dino)

dinoMID = dino.profile.mid
dinoProfile = dino.getProfile()

protectqr = settings["protectqr"]
protectkick = settings["protectkick"]
protectjoin = settings["protectjoin"]
protectinvite = settings["protectinvite"]
protectcancel = settings["protectcancel"]
protectname = settings["protectname"]
protectnote = settings["protectnote"]
protectcontact = settings["protectcontact"]

def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = dino.genOBSParams({'oid': dinoMID, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = dino.server.postContent('{}/talk/vp/upload.nhn'.format(str(dino.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        dino.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))
        os.remove("FadhilvanHalen.mp4")

def textx(text):
	for i in range(26):
		text = text.lower().replace("abcdefghijklmnopqrstuvwxyz"[i],"ᴀʙᴄᴅᴇғɢʜɪᴊᴋʟᴍɴᴏᴘϙʀsᴛᴜᴠᴡxʏᴢ"[i])
	return text
	
def timeChange(secs):
        mins, secs = divmod(secs,60)
        hours, mins = divmod(mins,60)
        days, hours = divmod(hours,24)
        weeks, days = divmod(days,7)
        months, weeks = divmod(weeks,4)
        year, months = divmod(months,12)
        text = ""
        if year != 0: text += "%02d ปี" % (year)
        if months != 0: text += "%02d เดือน" % (months)
        if weeks != 0: text += " %02d สัปดาห์" % (weeks)
        if days != 0: text += " %02d วัน" % (days)
        if hours !=  0: text +=  " %02d ชั่วโมง" % (hours)
        if mins != 0: text += " %02d นาที" % (mins)
        if secs != 0: text += " %02d วินาที" % (secs)
        if text[0] == " ":
                text = text[1:]
        return text
        
def mentionMembers(to, mids=[]):
    if dino in mids: mids.remove(dinoX)
    parsed_len = len(mids)//20+1
    result = ''
    mention = '@zeroxyuuki\n'
    no = 0
    for point in range(parsed_len):
        mentionees = []
        for mid in mids[point*20:(point+1)*20]:
            no += 1
            result += '%i. %s' % (no, mention)
            slen = len(result) - 12
            elen = len(result) + 3
            mentionees.append({'S': str(slen), 'E': str(elen - 4), 'M': mid})
            if mid == mids[-1]:
                result += ''
        if result:
            if result.endswith('\n'): result = result[:-1]
            dino.sendMessage(to, result, {'MENTION': json.dumps({'MENTIONEES': mentionees})}, 0)
        result = ''

def restartBot():
	print ("================ RESTART BOT ================")
	time.sleep(1)
	python = sys.executable
	os.execl(python, python, *sys.argv)

def executeCmd(op):
    global settings
    try:
    	
        if op.type == 5:
            if settings["autoblock"] == True:
                dino.blockContact(op.param1)
  
        if op.type == 124:
            if settings["autojoin"] == True:
                if dino.profile.mid in op.param3:
                    dino.acceptGroupInvitation(op.param1)
        
        if op.type == 122:
            if op.param1 in protectqr:
                if dino.getCompactGroup(op.param1).preventedJoinByTicket == False:
                    if op.param2 not in dinoMID:
                        try:
                            settings["blacklist"][op.param2] = True
                            dino.kickoutFromGroup(op.param1,[op.param2])
                            dino.reissueGroupTicket(op.param1)
                            X = dino.getCompactGroup(op.param1)
                            X.preventedJoinByTicket = True
                            dino.updateGroup(X)
                        except:pass
        
        if op.type == 133:
            if op.param1 in protectkick:
                if op.param2 not in dinoMID:
                    settings["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in settings["blacklist"]:
                            dino.kickoutFromGroup(op.param1,[op.param2])
                    except:pass
                    
        if op.type ==  130:
            if op.param1 in protectjoin:
                if op.param2 not in dinoMID:
                    settings["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in settings["blacklist"]:
                            dino.kickoutFromGroup(op.param1,[op.param2])
                    except:pass
        
        if op.type == 124:
            if op.param1 in protectinvite:
                if op.param2 not in dinoMID:
                    try:
                        invitor = op.param2
                        gotinvite = []
                        if "\x1e" in op.param3:
                            gotinvite = op.param3.split("\x1e")
                        else:
                            gotinvite.append(op.param3)
                        for u in gotinvite:
                            settings["blacklist"][op.param2] = True
                            if op.param2 not in dinoMID:
                               dino.kickoutFromGroup(op.param1,[op.param2])
                               dino.cancelGroupInvitation(op.param1,[op.param3])
                    except:pass
        
        if op.type == 126:
            if op.param1 in protectcancel:
                if op.param2 not in dinoMID:
                    settings["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in settings["blacklist"]:
                            dino.kickoutFromGroup(op.param1,[op.param2])
                            dino.findAndAddContactsByMid(op.param3)
                            dino.inviteIntoGroup(op.param1,[op.param3])
                    except:pass
        
        if op.type == 122:
            if op.param1 in protectname:
                if op.param3 == "1":
                    try:
                        if op.param1 in protectname:
                            if op.param2 not in dinoMID:
                                X = dino.getGroup(op.param1)
                                X.name = str(protectname[op.param1])
                                settings["blacklist"][op.param2] = True
                                dino.kickoutFromGroup(op.param1,[op.param2])
                                dino.updateGroup(X)
                    except:
                        traceback.print_exc()
        
        if op.type == 26:
            msg = op.message
            if msg.to in protectnote:
                if msg._from not in dinoMID:
                    if msg.contentType == 16:
                        dino.kickoutFromGroup(msg.to, [msg._from])
                    if msg.contentType == 18:
                        dino.kickoutFromGroup(msg.to, [msg._from])
        
        if op.type == 26:
            msg = op.message
            if msg.to in protectcontact:
                if msg._from not in dinoMID:
                    if msg.contentType == 13:
                        dino.kickoutFromGroup(msg.to, [msg._from])
        
        if op.type == 32:
            if op.param2 not in dinoMID:
                if op.param2  in settings["blacklist"]:
                    dino.kickoutFromGroup(op.param1, [op.param2])
                    dino.findAndAddContactsByMid(op.param3)
                    dino.inviteIntoGroup(op.param1, [op.param3]) 
                    dino.sendText(op.param1, "ไม่อนุญาตให้บัญชีดำยกเชิญ")
                
        if op.type == 133:
            if op.param2 not in dinoMID:
                if op.param2 in settings["blacklist"]:
                    dino.kickoutFromGroup(op.param1,[op.param2])
                    G = dino.getGroup(op.param1)
                    G.preventedJoinByTicket = True
                    dino.updateGroup(G)
                    settings["blacklist"][op.param2] = True
                    dino.sendText(op.param1, "ไม่อนุญาตให้บัญชีดำเตะ")
                    
        if op.type == 55:
            if op.param2 not in dinoMID:
                if op.param2 in settings["blacklist"]:
                    dino.kickoutFromGroup(op.param1,[op.param2])
                    dino.sendText(op.param1, "ไม่อนุญาตให้บัญชีดำอ่าน")
        
        if op.type == 124:
            if op.param3 in settings["blacklist"]:
                if op.param2 not in dinoMID:
                    dino.cancelGroupInvitation(op.param1,[op.param3])
                    dino.sendText(op.param1, "กรุณาอย่าเชิญบัญชีดำเข้าร่วมกลุ่ม")
                    
        if op.type == 26:
            msg = op.message
            if msg._from not in dinoMID:
                if msg._from in settings["blacklist"]:
                    try:
                        dino.kickoutFromGroup(msg.to, [msg._from])
                        dino.sendText(msg.to, "ไม่อนุญาตให้บัญชีดำพิมพ์")
                    except:pass
        
        if op.type == 25:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.contentType == 13:
                if settings["wblacklist"] == True:
                    if msg.contentMetadata["mid"] not in dino.profile.mid:
                        if msg.contentMetadata["mid"] in settings["blacklist"]:
                            dino.sendText(msg.to, "เพิ่มบัญชีนี้ในรายการแบนเรียบร้อยแล้ว.")
                            settings["wblacklist"] = False
                        else:
                            settings["blacklist"][msg.contentMetadata["mid"]] = True
                            settings["wblacklist"] = False
                            dino.sendText(msg.to, "เพิ่มบัญชีนี้ในรายการแบนเรียบร้อยแล้ว.")
                if settings["dblacklist"] == True:
                    if msg.contentMetadata["mid"] not in dino.profile.mid:
                        if msg.contentMetadata["mid"] in settings["blacklist"]:
                            del settings["blacklist"][msg.contentMetadata["mid"]]
                            dino.sendText(msg.to, "ลบบัญชีนี้ในรายการแบนเรียบร้อยแล้ว.")
                            settings["dblacklist"] = False
                        else:
                            settings["dblacklist"] = False
                            dino.sendText(msg.to, "ลบบัญชีนี้ในรายการแบนเรียบร้อยแล้ว.")
        
        if op.type == 26:
            msg = op.message
            if msg._from not in dinoMID:
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    if settings["notagkick"] == True:
                        name = re.findall(r'@(\w+)', msg.text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for mention in mentionees:
                            if mention ['M'] in dinoMID:
                                dino.kickoutFromGroup(msg.to, [msg._from])
        
        if op.type in [25, 26]:
            msg = op.message
            if msg.contentType == 16:
                if msg.toType in [2,1,0]:
                    try:
                        if settings["autopost"] == True:
                            purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                            for x in purl:
                                dino.sendContact(msg.to, x)
                    except:pass
        
        if op.type == 25:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                if msg.toType == 0:
                    if sender != dino.profile.mid:
                        to = sender
                    else:
                        to = receiver
                elif msg.toType == 1:
                    to = receiver
                elif msg.toType == 2:
                	to = receiver
                if msg.contentType == 1:
                     if settings["setpicture"] == True:
                         path = dino.downloadObjectMsg(msg_id)
                         settings["setpicture"] = False
                         dino.updateProfilePicture(path)
                         dino.sendText(msg.to,textx("succeessfully changed image"))
        
        if op.type in [19, 133]:
            if op.param3 in dinoMID:
                if op.param2 not in dinoMID:
                    settings["blacklist"][op.param2] = True
        
        if op.type == 25:
            msg = op.message
            to = msg.to
            text = msg.text
            sender = msg._from
            msg_id = msg.id
            if msg.contentType == 0:
                if msg.text is None:
                    return
                    
                if msg.text.lower() == "/help":
                    text = f"\n".join([
                    "  🗡️DANGROCKPK🛡️  ",
                    "help [คำสั่งทั้งหมด",
                    "me [คทตัวเอง]",
                    "runtime [เวลาออนบอท]",
                    "status [เช็คบัค]",
                    "tagall [แทคทุกคน]",
                    "speed [ความเร็ว]",
                    "picture [รูปเรา]",
                    "√uppicture [อัพรูป]",
                    "√name (@) [ชื่อเรา]",
                    "√upname (ข้อความ) [อัพชื่อ]",
                    "√bio [ตัสเรา]",
                    "√upbio (ข้อความ) [อัพตัส]",
                    "√upvdo (ลิ้งค์) [อัพวิดีโอโปรไฟล์]",
                    "√mid (@) [มิดเรา]",
                    "√restart [รีบอทใหม่]",
                    "√kickchat (@) [เตะลบแชท]",
                    "√kick (@) [เตะออกจากกลุ่ม]",
                    "√kickjs (@) [แทคเตะรวบ]",
                    "√leave [ออกกลุ่ม]",
                    "√spam (เลข) [สแปมเลข]",
                    "√grouplist [เช็คกลุ่ม]",
                    "√leavegroup (เลข) [ออกกลุ่ม]",
                    "√conbanlist [รายชื่อคท.ดำ]",
                    "√banlist [รายชื่อดำ]",
                    "√clearban [ล้างดำ]",
                    "√unsend [เลข] [ยกเลิกข้อความ]",
                    "√settings [เช็คตั้งค่า]",
                    "√protectlisr [ตั้งค่าป้องกัน]",
                    "√ban [เพิ่มดำ คท.]",
                    "√unban [ลบดำ คท.]",
                    "√ban (@) [เพิ่มดำ]",
                    "√unban (@) [ลบดำ]",
                    "√kickbangroup [ล่าดำทุกกลุ่ม]",
                    "√chackjs [เช็คข้อความบิน]",
                    "√chackpy [เช็คข้อความบิน]",
                    "√setkickjs (ข้อความ) [ตั้งคำสั่งบิน]",
                    "√setkickpy (ข้อความ) [ตั้งคำสั่งบิน]",
                    "√kick on/off [ระบบบิน]",
                    "√contactpost on/off [ดึงคทโพส]",
                    "√autojoin on/off [ระบบเข้ากลุ่ม]",
                    "√autoblock on/off [ระบบบล็อค]",
                    "√notag on/off [ระบบแทคเตะ]",
                    "   ✓CHINCHANGCHING ✓ ",
                    "√protectkick on/off [กันเตะ]",
                    "√protectinvite on/off [กันเชิญ]",
                    "√protectqr on/off [กันลิ้ง]",
                    "√protectcancel on/off [กันยกเชิญ]",
                    "√protectjoin on/off [กันเข้า]",
                    "√protectnote on/off [กันโน็ต]",
                    "√protectname on/off [กันชื่อ]",
                    "√protectcontact on/off [กันส่งคท]",
                    ])
                    dino.sendText(msg.to,str(textx(text)))
                    
                if msg.text.lower() == settings["kickallpy"]:
                    if settings["text"] == True:
                        G = dino.getGroup(msg.to)
                        members = [G.mid for G in G.members]
                        AsyncKick(dino,msg.to,members)
                
                if msg.text.lower() == "/status":
                    if dino.profile.mid not in dinoMID:
                            return
                    try:
                        dino.inviteIntoChat(to, {dino.profile.mid})
                        limit = False
                    except:
                    	limit = True
                    dino.sendText(to, "limit" if limit else "ready")
                
                if msg.text.lower().startswith("/upvdo "):
                    link = msg.text.split("/upvdo ")[1]
                    contact = dino.getContact(sender)
                    dino.sendText(to, "ประเภท: โปรไฟล์\n • รายละเอียด: เปลี่ยน URL วิดีโอ\n • สถานะ: กำลังดาวน์โหลด ...")
                    pic = "http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus)
                    subprocess.getoutput('youtube-dl --format mp4 --output TeamAnuBot.mp4 {}'.format(link))
                    pict = dino.downloadFileURL(pic)
                    vids = "TeamAnuBot.mp4"
                    changeVideoAndPictureProfile(pict, vids)
                    dino.sendText(to, "ประเภท: โปรไฟล์\n • รายละเอียด: เปลี่ยน URL วิดีโอ\n • สถานะ: สำเร็จ")
                    os.remove("TeamAnuBot.mp4")
                
                if msg.text.lower().startswith("/progroup "):
                    pro = msg.text.split("/progroup ")[1]
                    groups = dino.getGroupIdsJoined()
                    for group in groups:
                        time.sleep(0.20)
                        dino.sendText(group, pro)
                    dino.sendText(msg.to, "ประกาศเสร็จแล้วทั้งหมด {} คลับ ".format(str(len(groups))))
                
                if msg.text.lower().startswith("/postgroup "):
                    pro = msg.text.split("/postgroup ")[1]
                    groups = dino.getGroupIdsJoined()
                    for group in groups:
                        time.sleed(0.20)
                        dino.sendPostToTalk(group, pro)
                    dino.sendText(msg.to, "แชร์เสร็จแล้วทั้งหมด {} คลับ ".format(str(len(groups))))
                
                if msg.text.lower() == "/restart":
                    dino.sendText(to, "Rebooting....")
                    restartBot()
                 
                if msg.text.lower().startswith("/spam "):
                    number = msg.text.split("/spam ")[1]
                    if len(number) > 0:
                        if number.isdigit():
                            number = int(number)
                            if number > 1000000:
                            	dino.sendText(to,"invalid >_< ! NUM : 1000000.")
                            else:
                                for i in range(0,number):
                                    dino.sendText(to,str(number))
                                    number -= 1
                        else:
                            dino.sendText(to,"Please specify a valid number.")
                 
                if msg.text.lower().startswith("/kickchat "):
                    vkick0 = msg.text.split("/kickchat ")[1]
                    vkick1 = vkick0.rstrip()
                    vkick2 = vkick1.replace("@","")
                    vkick3 = vkick2.rstrip()
                    _name = vkick3
                    gs = dino.getGroup(msg.to)
                    targets = []
                    for s in gs.members:
                        if _name in s.displayName:
                            targets.append(s.mid)
                    if targets == []:
                        pass
                    else:
                        for target in targets:
                            try:
                                dino.kickoutFromGroup(msg.to,[target])
                                dino.findAndAddContactsByMid(target)
                                dino.inviteIntoGroup(msg.to,[target])
                                dino.cancelGroupInvitation(msg.to,[target])
                            except:
                                pass
                  
                if msg.text.lower() == "/conbanlist":
                    if settings["blacklist"] == {}:
                        dino.sendMessage(to ,"บัญชีที่อยู่ในรายการแบน")
                    else:
                        for bl in settings["blacklist"]:
                            dino.sendText(to, text=None, contentMetadata={'mid': bl}, contentType=13)
  
                if msg.text.lower() == "/leave":
                    dino.leaveGroup(to)
                    
                if msg.text.lower() == "/grouplist":
                    text = "รายชื่อกลุ่มทั้งหมด:\n"
                    len_Group = 100
                    groups = dino.getGroupIdsJoined()
                    n = 0
                    for number in range(len(groups)//len_Group+1):
                        for group in groups[number*len_Group:(number+1)*len_Group]:
                            n += 1
                            group = dino.getGroup(group)
                            text += f"{n}. {group.name}|{len(group.members)}\n"
                        if text.endswith('\n'):
                            text = text[:-1]
                            dino.sendText(msg.to, text)
                        text = ""
                    
                if msg.text.lower().startswith("/leavegroup "):
                    text = msg.text.split("/leavegroup ")[1]
                    try:
                        int(text)
                        s = True
                    except:
                        s = False
                    if not s:
                        dino.sendText(msg.to, "ใส่เป็นตัวเลขเท่านั้น")
                    else:
                        groups = dino.getGroupIdsJoined()
                        if int(text) > len(groups):
                            dino.sendText(msg.to, "ไม่พบลำดับ")
                        else:
                            group = groups[int(text)-1]
                            dino.leaveGroup(group)
                            if msg.to != group:
                                dino.sendText(msg.to, f"ออกกลุ่ม {dino.getGroup(group).name} เสร็จสิ้น")
                    
                if msg.text.lower() == "/speed":
                    start = time.time()
                    dino.getProfile()
                    dino.sendText(to, "Speed: %.4f ms" %(time.time() - start))
                    
                if msg.text.lower() == "/me":
                    dino.generateReplyMessage(msg.id) 
                    dino.sendReplyMessage(msg.id, to, None, contentMetadata={'mid': dinoMID}, contentType=13)
                    
                if msg.text.lower() == "/runtime":
                    timeNow = time.time()
                    runtime = timeNow - botStart
                    runtime = timeChange(runtime)
                    dino.sendText(to,str(runtime))
                    
                if msg.text.lower() == "/tagall":
                    members = []
                    if msg.toType == 1:
                        room = dino.getCompactRoom(to)
                        members = [mem.mid for mem in room.contacts]
                    elif msg.toType == 2:
                        group = dino.getCompactGroup(to)
                        members = [mem.mid for mem in group.members]
                    else:
                        return dino.sendText(to, 'Failed mentionall members, use this command only on room or group chat')
                    if members:
                        mentionMembers(to, members)
                        
                if msg.text.lower() == "/name":
                    d = dino.getContact(dinoMID)
                    dino.generateReplyMessage(msg.id)
                    dino.sendReplyMessage(msg.id, to, ""+str(d.displayName))
                    
                if msg.text.lower().startswith("/name "):
                    text = msg.text.split("/name ")[1]
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        for mention in mentionees:
                            if mention["M"] not in lists:
                                lists.append(mention["M"])
                        for ls in lists:
                            contact = dino.getContact(ls)
                            mi_d = contact.displayName
                            dino.sendText(msg.to, mi_d)
                    
                if msg.text.lower() == "/mid":
                    dino.generateReplyMessage(msg.id)
                    dino.sendReplyMessage(msg.id, to,dinoMID)
                    
                if msg.text.lower().startswith("/mid "):
                    text = msg.text.split("/mid ")[1]
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        for mention in mentionees:
                            if mention["M"] not in lists:
                                lists.append(mention["M"])
                        ret_ = ""
                        for ls in lists:
                            ret_ += "{}".format(str(ls))
                        dino.generateReplyMessage(msg.id)
                        dino.sendReplyMessage(msg.id, to, str(ret_))
                    
                if msg.text.lower() == "/bio":
                    d = dino.getContact(dinoMID)
                    dino.sendReplyMessage(msg.id, to, ""+str(d.statusMessage))
                
                if msg.text.lower() == "/picture":
                    me = dino.getContact(dinoMID)
                    dino.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/" + me.pictureStatus)
                    
                if msg.text.lower() == "/uppicture":
                    if settings["setpicture"] == False:
                        settings["setpicture"] = True
                        dino.sendText(msg.to, "ส่งรูปลงมา")
                    
                if msg.text.lower().startswith("/upname "):
                    sep = text.split(" ")
                    name = text.replace(sep[0] + " ","")
                    if len(name) <= 999:
                        profile = dino.getProfile()
                        profile.displayName = name
                        dino.updateProfile(profile)
                        dino.sendText(to, "✯͜͡❂ name : {}".format(name))
                        
                if msg.text.lower().startswith("/upbio "):
                    sep = text.split(" ")
                    bio = text.replace(sep[0] + " ","")
                    if len(bio) <= 100000:
                        profile = dino.getProfile()
                        profile.statusMessage = bio
                        dino.updateProfile(profile)
                        dino.sendText(to, "✯͜͡❂ bio : {}".format(bio))
   
                if msg.text.lower() == "/chackjs":
                    dino.sendText(msg.to, f'ข้อความที่คุณตั้ง = {settings["kickalljs"]}')
                    
                if msg.text.lower() == "/chackpy":
                    dino.sendText(msg.to, f'ข้อความที่คุณตั้ง = {settings["kickallpy"]}')
                    
                if msg.text.lower() == "/banlist":
                    if settings["blacklist"] == {}:
                        dino.sendText(to, "ไม่พบบัญชีที่อยู่ในรายการแบน")
                    else:
                        text = 'บัญชีที่อยู่ในรายการแบน:'
                        for mi_d in settings["blacklist"]:
                            text += "\n- {}".format(dino.getContact(mi_d).displayName)
                        dino.sendText(to, str(text))
                        
                if msg.text.lower() == "/clearban":
                    settings["blacklist"] = {}
                    dino.sendText(msg.to, "ลบแบล็คลิสแล้ว")
                    
                if msg.text.lower() == "/ban":
                    settings["wblacklist"] = True
                    dino.sendText(to, "• กรุณาส่ง Contact •")
                    
                if msg.text.lower() == "/unban":
                    settings["dblacklist"] = True
                    dino.sendText(to, "• กรุณาส่ง Contact •")
                    
                if msg.text.lower().startswith("/ban "):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"] [0] ["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        if target not in dinoMID:
                            try:
                                settings["blacklist"][target] = True
                                dino.sendText(to, "เพิ่ม {} ในบัญชีดำเรียบร้อยแล้ว.".format(dino.getContact(target).displayName))
                            except:
                                dino.sendText(to, "เกิดข้อผิดพลาด")
                                
                if msg.text.lower().startswith("/unban "):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"] [0] ["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        if target not in dinoMID:
                            try:
                                del settings["blacklist"][target]
                                dino.sendText(to, "ลบ {} ในบัญชีดำเรียบร้อยแล้ว".format(dino.getContact(target).displayName))
                            except:
                                dino.sendText(to, "เกิดข้อผิดพลาด")
                    
                if msg.text.lower() == "/kickbangroup":
                    groups = dino.getGroupIdsJoined()
                    for x in groups:
                        found = []
                        mem = [m.mid for m in dino.getGroup(x).members]
                        for mid in settings["blacklist"]:
                            if mid in mem: found.append(mid)
                        if found:
                            for blc in found:
                                try:
                                    dino.kickoutFromGroup(x, [blc])
                                except: dino.sendText(dinoMID, "บัคเตะแล้ว");break
                            dino.sendText(x, "เจอดำในกลุ่มนี้")
                    dino.sendText(to, "ค้นหาบัญชีดำแล้วไล่เตะจากทุกกลุ่มแล้ว")
                    
                if msg.text.lower().startswith("/setkickjs "):
                    text = msg.text.split(" ")[1]
                    if text == settings["kickalljs"]:
                        dino.sendText(msg.to, "ตั้งไว้อยู่แล้ว")
                    else:
                        settings["kickalljs"] = text
                        dino.sendText(msg.to, "ตั้งเสร็จสิ้น")
                     
                if msg.text.lower().startswith("/setkickpy "):
                    text = msg.text.split(" ")[1]
                    if text == settings["kickallpy"]:
                        dino.sendText(msg.to, "ตั้งไว้อยู่แล้ว")
                    else:
                        settings["kickallpy"] = text
                        dino.sendText(msg.to, "ตั้งเสร็จสิ้น")
   
                if msg.text.lower().startswith("/kick "):
                    text = msg.text.split("/kick ")[1]
                    if text == "on":
                        settings["text"] = True
                        dino.sendText(to, "เปิดระบบบินแล้ว")
                    elif text == "off":
                        settings["text"] = False
                        dino.sendText(to, "ปิดระบบบินแล้ว")
                        
                if msg.text.lower().startswith("/autojoin "):
                    text = msg.text.split("/autojoin ")[1]
                    if text == "on":
                        settings["autojoin"] = True
                        dino.sendText(to, "เปิดระบบเข้าแล้ว")
                    elif text == "off":
                        settings["autojoin"] = False
                        dino.sendText(to, "ปิดระบบเข้าแล้ว")
                        
                if msg.text.lower().startswith("/autoblock "):
                    text = msg.text.split("/autoblock ")[1]
                    if text == "on":
                        settings["autoblock"] = True
                        dino.sendText(to, "เปิดระบบบล็อคแล้ว")
                    elif text == "off":
                        settings["autoblock"] = False
                        dino.sendText(to, "ปิดระบบบล็อคแล้ว")
                        
                if msg.text.lower().startswith("/notag "):
                    text = msg.text.split("/notag ")[1]
                    if text == "on":
                        settings["notagkick"] = True
                        dino.sendText(to, "เปิดระบบห้ามแท็คแล้ว")
                    elif text == "off":
                        settings["notagkick"] = False
                        dino.sendText(to, "ปิดระบบห้ามแท็คแล้ว")
                   
                if msg.text.lower().startswith("/contactpost "):
                    text = msg.text.split("/contactpost ")[1]
                    if text == "on":
                        settings["autopost"] = True
                        dino.sendText(to, "แชร์โพสลงมา")
                    elif text == "off":
                        settings["autopost"] = False
                        dino.sendText(to, "ปิดดึงคทโพสแล้ว")
   
                if msg.text.lower() == "/protectlist":
                    md = "🔰 เช็คระบบป้องกัน 🔰\n"
                    if msg.to in protectqr: md+="⚔️ ✔ ป้องกัน ลิ้ง\n"
                    else: md+="⚔️ ✖ ป้องกัน ลิ้ง\n"
                    if msg.to in protectjoin: md+="⚔️ ✔ ป้องกัน คนเข้า\n"
                    else: md+="⚔️ ✖ ป้องกัน คนเข้า\n"
                    if msg.to in protectkick: md+="⚔️ ✔ ป้องกัน กันเตะ\n"
                    else: md+="⚔️ ✖ ป้องกัน กันเตะ\n"
                    if msg.to in protectinvite: md+="⚔️️ ✔ ป้องกัน กันเชิญ\n"
                    else: md+="⚔️ ✖ ป้องกัน กันเชิญ\n"
                    if msg.to in protectname: md+="⚔️️ ✔ ป้องกัน ชื่อห้อง\n"
                    else: md+="⚔️ ✖ ป้องกัน ชื่อห้อง\n"
                    if msg.to in protectcancel: md+="⚔️️ ✔ ป้องกัน ยกเชิญ\n"
                    else: md+="⚔️ ✖ ป้องกัน ยกเชิญ\n"
                    if msg.to in protectnote: md+="⚔️️ ✔ ป้องกัน กันโน๊ต\n"
                    else: md+="⚔️ ✖ ป้องกัน กันโน๊ต\n"
                    if msg.to in protectcontact: md+="⚔️️ ✔ ป้องกัน กันส่งคท\n"
                    else: md+="⚔️ ✖ ป้องกัน กันส่งคท"
                    dino.sendText(msg.to, md)
                        
                if msg.text.lower().startswith("/kick "):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets[0].append(x["M"])
                    for target in targets:
                        try:
                            AsyncKick(dino,msg.to,[target])
                        except:
                            dino.sendText(msg.to, "เกิดข้อผิดพลาด")
 
                if msg.text.lower().startswith("/protectqr "):
                    text = msg.text.split("/protectqr ")[1]
                    if text == "on":
                        if msg.to in protectqr:
                            msgs = "ป้องกัน URL ถูกเปิดใช้งานอยู่แล้ว"
                        else:
                            protectqr.append(msg.to)
                            ginfo = dino.getGroup(msg.to)
                            msgs = "ป้องกัน URL เปิดใช้งาน\nɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                        dino.sendText(msg.to, "「sᴛᴀᴛᴜs ᴘʀᴏᴛᴇᴄᴛ ᴜʀʟ」\n" + msgs)
                    elif text == "off":
                        if msg.to in protectqr:
                            protectqr.remove(msg.to)
                            ginfo = dino.getGroup(msg.to)
                            msgs = "ป้องกัน URL ปิดใช้งาน\nɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                        else:
                            msgs = "ป้องกัน URL ปิดใช้งานอยู่แล้ว"
                        dino.sendText(msg.to, "「sᴛᴀᴛᴜs ᴘʀᴏᴛᴇᴄᴛ ᴜʀʟ」\n" + msgs)          
                       
                if msg.text.lower().startswith("/protectkick "):
                    text = msg.text.split("/protectkick ")[1]
                    if text == "on":
                        if msg.to in protectkick:
                             msgs = "ป้องกันเตะถูกเปิดใช้งานอยู่แล้ว"
                        else:
                            protectkick.append(msg.to)
                            ginfo = dino.getGroup(msg.to)
                            msgs = "ป้องกันลบสมาชิกเปิดใช้งาน\nɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                        dino.sendText(msg.to, "「sᴛᴀᴛᴜs ᴘʀᴏᴛᴇᴄᴛ ᴋɪᴄᴋ」\n" + msgs)
                    elif text == "off":
                        if msg.to in protectkick:
                            protectkick.remove(msg.to)
                            ginfo = dino.getGroup(msg.to)
                            msgs = "ป้องกันลบสมาชิกปิดใช้งาน\nɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                        else:
                            msgs = "ป้องกันเตะปิดใช้งานอยู่แล้ว"
                        dino.sendText(msg.to, "「sᴛᴀᴛᴜs ᴘʀᴏᴛᴇᴄᴛ ᴋɪᴄᴋ」\n" + msgs)
                       
                if msg.text.lower().startswith("/protectjoin "):
                    text = msg.text.split("/protectjoin ")[1]
                    if text == "on":
                        if msg.to in protectjoin:
                            msgs = "ป้องกันคนเข้าถูกเปิดใช้งานอยู่แล้ว"
                        else:
                            protectjoin.append(msg.to)
                            ginfo = dino.getGroup(msg.to)
                            msgs = "ป้องกันคนเข้าเปิดใช้งาน\nɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                        dino.sendText(msg.to, "「sᴛᴀᴛᴜs ᴘʀᴏᴛᴇᴄᴛ ᴊᴏɪɴ」\n" + msgs)
                    elif text == "off":
                        if msg.to in protectjoin:
                            protectjoin.remove(msg.to)
                            ginfo = dino.getGroup(msg.to)
                            msgs = "ป้องกันคนเข้าปิดใช้งาน\nɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                        else:
                            msgs = "ป้องกันคนเข้าถูกปิดใช้งานอยู่แล้ว"
                        dino.sendText(msg.to, "「sᴛᴀᴛᴜs ᴘʀᴏᴛᴇᴄᴛ ᴊᴏɪɴ」\n" + msgs)
                       
                if msg.text.lower().startswith("/protectcancel "):
                    text = msg.text.split("/protectcancel ")[1]
                    if text == "on":
                        if msg.to in protectcancel:
                            msgs = "ป้องกันยกเชิญถูกเปิดใช้งานอยู่แล้ว"
                        else:
                            protectcancel.append(msg.to)
                            ginfo = dino.getGroup(msg.to)
                            msgs = "ป้องกันกันยกเปิดใช้งาน\nɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                        dino.sendText(msg.to, "「sᴛᴀᴛᴜs ᴘʀᴏᴛᴇᴄᴛ ᴄᴀɴᴄᴇʟ」\n" + msgs)
                    elif text == "off":
                        if msg.to in protectcancel:
                            protectcancel.remove(msg.to)
                            ginfo = dino.getGroup(msg.to)
                            msgs = "ป้องกันยกเชิญใช้งาน\nɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                        else:
                            msgs = "ป้องกันยกเชิญปิดใช้งานอยู่แล้ว"
                        dino.sendText(msg.to, "「sᴛᴀᴛᴜs ᴘʀᴏᴛᴇᴄᴛ ᴄᴀɴᴄᴇʟ」\n" + msgs)
                       
                if msg.text.lower().startswith("/protectnote "):
                    text = msg.text.split("/protectnote ")[1]
                    if text == "on":
                        if msg.to in protectnote:
                             msgs = "ป้องกันโน๊ตกลุ่มถูกเปิดใช้งานอยู่แล้ว"
                        else:
                            protectnote.append(msg.to)
                            ginfo = dino.getGroup(msg.to)
                            msgs = "ป้องกันโน๊ตกลุ่มเปิดใช้งาน\nɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                        dino.sendText(msg.to, "「sᴛᴀᴛᴜs ᴘʀᴏᴛᴇᴄᴛ ɴᴏᴛᴇ」\n" + msgs)
                    elif text == "off":
                        if msg.to in protectnote:
                            protectnote.remove(msg.to)
                            ginfo = dino.getGroup(msg.to)
                            msgs = "ป้องกันโน๊ตกลุ่มปิดใช้งาน\nɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                        else:
                            msgs = "ป้องกันโน๊ตกลุ่มถูกปิดใช้งานอยู่แล้ว"
                        dino.sendText(msg.to, "「sᴛᴀᴛᴜs ᴘʀᴏᴛᴇᴄᴛ ɴᴏᴛᴇ」\n" + msgs)
                       
                if msg.text.lower().startswith("/protectname "):
                    text = msg.text.split("/protectname ")[1]
                    if text == "on":
                        if msg.to in protectname:
                            msgs = "ป้องกันชื่อกลุ่มถูกเปิดใช้งานอยู่แล้ว"
                        else:
                            protectname.append(msg.to)
                            ginfo = dino.getGroup(msg.to)
                            msgs = "ป้องกันชื่อกลุ่มเปิดใช้งาน\nɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                        dino.sendText(msg.to, "「sᴛᴀᴛᴜs ᴘʀᴏᴛᴇᴄᴛ ɴᴀᴍᴇ」\n" + msgs)
                    elif text == "off":
                        if msg.to in protectname:
                            protectname.remove(msg.to)
                            ginfo = dino.getGroup(msg.to)
                            msgs = "ป้องกันชื่อกลุ่มปิดใช้งาน\nɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                        else:
                            msgs = "ป้องกันชื่อกลุ่มถูกปิดใช้งานอยู่แล้ว"
                        dino.sendText(msg.to, "「sᴛᴀᴛᴜs ᴘʀᴏᴛᴇᴄᴛ ɴᴀᴍᴇ」\n" + msgs)
                       
                if msg.text.lower().startswith("/protectinvite "):
                    text = msg.text.split("/protectinvite ")[1]
                    if text == "on":
                        if msg.to in protectinvite:
                            msgs = "ป้องกันเชิญกลุ่มถูกเปิดใช้งานอยู่แล้ว"
                        else:
                            protectinvite.append(msg.to)
                            ginfo = dino.getGroup(msg.to)
                            msgs = "ป้องกันเชิญกลุ่มเปิดใช้งาน\nɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                        dino.sendText(msg.to, "「sᴛᴀᴛᴜs ᴘʀᴏᴛᴇᴄᴛ ɪɴᴠɪᴛᴇ」\n" + msgs)
                    elif text == "off":
                        if msg.to in protectinvite:
                            protectinvite.remove(msg.to)
                            ginfo = dino.getGroup(msg.to)
                            msgs = "ป้องกันเชิญกลุ่มปิดใช้งาน\nɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                        else:
                            msgs = "ป้องกันเชิญกลุ่มถูกปิดใช้งานอยู่แล้ว"
                        dino.sendText(msg.to, "「sᴛᴀᴛᴜs ᴘʀᴏᴛᴇᴄᴛ ɪɴᴠɪᴛᴇ」\n" + msgs)
                     
                if msg.text.lower().startswith("/protectcontact "):
                    text = msg.text.split("/protectcontact ")[1]
                    if text == "on":
                        if msg.to in protectcontact:
                            msgs = "ป้องกันส่งคทกลุ่มถูกเปิดใช้งานอยู่แล้ว"
                        else:
                            protectcontact.append(msg.to)
                            ginfo = dino.getGroup(msg.to)
                            msgs = "ป้องกันส่งคทกลุ่มเปิดใช้งาน\nɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                        dino.sendText(msg.to, "「sᴛᴀᴛᴜs ᴘʀᴏᴛᴇᴄᴛ conтacт」\n" + msgs)
                    elif text == "off":
                        if msg.to in protectcontact:
                            protectcontact.remove(msg.to)
                            ginfo = dino.getGroup(msg.to)
                            msgs = "ป้องกันส่งคทกลุ่มปิดใช้งาน\nɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                        else:
                            msgs = "ป้องกันส่งคทกลุ่มถูกปิดใช้งานอยู่แล้ว"
                        dino.sendText(msg.to, "「sᴛᴀᴛᴜs ᴘʀᴏᴛᴇᴄᴛ conтacт」\n" + msgs)
                
                if msg.text.lower().startswith("/unsend "):
                    text = msg.text.split("/unsend ")[1]
                    if text.isdigit():
                        mess = dino.getRecentMessagesV2(msg.to,999)
                        mes = []
                        for x in mess:
                            if x._from == dinoMID:
                                mes.append(x.id)
                                if len(mes) == int(text):break
                        for b in mes:
                            try:dino.unsendMessage(b)
                            except:pass
                    else:dino.sendText(msg.to,"「   Usage 」\n/unsend num")
                
                if msg.text.lower().startswith("/kickjs "):
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    targets = []
                    imdino = 'dino.js gid={} token={} app={}'.format(to, dino.authToken, "ANDROIDLITE 2.17.0 Android OS 9")
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        imdino += ' uid={}'.format(target)
                    success = execute_js(imdino)
                
                if msg.text.lower() == settings["kickalljs"]:
                    if settings["text"] == True:
                        xyz = dino.getGroup(to)
                        mem = [c.mid for c in xyz.members]
                        targets = []
                        for x in mem:
                            if x not in ["u5561c11f5501c0dc986bf9d585898b9e",dino.profile.mid]:targets.append(x)
                        if targets:
                            imdino = 'dino.js gid={} token={} app={}'.format(to, dino.authToken, "ANDROIDLITE 2.17.0 Android OS 9")
                            for target in targets:
                                imdino += ' uid={}'.format(target)
                            success = execute_js(imdino)
                            if success:dino.sendText(to, "เตะทั้งหมด %i คนแล้ว." % len(targets))
                            else:dino.sendText(to, "เกิดข้อผิดพลาดในการเตะ %i คนในห้อง." % len(targets))
                        else:dino.sendText(to, "ไม่มีคนอยู่ในห้อง.")
                    
                if msg.text.lower().startswith("/exec "):
                    try:
                        exec(msg.text.split("/exec ")[1])
                    except:
                        error = traceback.format_exc()
                        dino.sendText(msg.to, str(error).strip())
                    
    except:
        traceback.print_exc()

if __name__ == "__main__":
    while True:
        ops = oepoll.singleTrace(count=50)
        try:
            if ops is not None:
                for op in ops:
                    if op.type != 0:
                        oepoll.setRevision(op.revision)
                        executeCmd(op)
        except Exception as e:
            print(str(e))
        except:
            traceback.print_exc()
            
